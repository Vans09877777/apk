# Floating Launcher (Kotlin, Android native)

Floating overlay launcher: tombol melayang yang bisa diseret, auto hide, dan menu peluncur aplikasi.
Tanpa dependensi pihak ketiga (hanya Android SDK + Kotlin).

## Build APK
1. Buka folder ini di **Android Studio** (Koala / 2024.1+ dengan JDK 17), tunggu Gradle sync.
2. Menu **Build → Build APK(s)**, atau lewat terminal (setelah sync membuat wrapper):
   - `./gradlew assembleDebug`   → `app/build/outputs/apk/debug/app-debug.apk`
   - `./gradlew assembleRelease` → `app/build/outputs/apk/release/app-release.apk`
   (jika `gradlew` belum ada: `gradle wrapper --gradle-version 8.7`)
3. Pasang APK, buka aplikasi, berikan izin **Tampil di atas aplikasi lain**, lalu **Mulai Overlay**.

minSdk 29 (Android 10) · targetSdk 34.

## Build otomatis lewat GitHub Actions
Push proyek ini ke GitHub (branch `main`). Workflow `.github/workflows/build.yml` akan membangun APK otomatis.
Unduh hasilnya di tab **Actions → run terbaru → Artifacts → FloatingLauncher-apk**.
