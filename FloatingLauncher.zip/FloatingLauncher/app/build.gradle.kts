plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.floatlauncher.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.floatlauncher.app"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // Ditandatangani dengan kunci debug supaya APK release langsung bisa dipasang.
            // Ganti dengan keystore sendiri sebelum rilis ke Play Store.
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
// Tanpa dependensi AndroidX/Compose: hanya SDK Android native -> APK kecil & ringan.
