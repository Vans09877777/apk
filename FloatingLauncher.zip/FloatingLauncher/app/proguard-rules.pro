# Tidak ada aturan khusus; tidak memakai refleksi.
