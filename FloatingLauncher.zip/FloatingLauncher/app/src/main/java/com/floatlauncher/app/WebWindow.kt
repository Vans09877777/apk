package com.floatlauncher.app

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** Ikon bulat dengan satu huruf (untuk entri jendela web di menu). */
class LetterIcon(private val letter: String, fillColor: Int) : Drawable() {
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = fillColor }
    private val tx = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }

    override fun draw(c: Canvas) {
        val b = bounds
        val r = minOf(b.width(), b.height()) / 2f
        c.drawCircle(b.exactCenterX(), b.exactCenterY(), r, bg)
        tx.textSize = r * 1.1f
        c.drawText(letter, b.exactCenterX(), b.exactCenterY() - (tx.descent() + tx.ascent()) / 2f, tx)
    }

    override fun setAlpha(alpha: Int) { bg.alpha = alpha; tx.alpha = alpha }
    override fun setColorFilter(cf: ColorFilter?) { bg.colorFilter = cf; tx.colorFilter = cf }
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}

/**
 * Jendela floating buatan sendiri (overlay) berisi WebView.
 * Header: seret untuk memindah, chip untuk transparansi, pojok kanan-bawah untuk ubah ukuran.
 */
@SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
class WebWindow(
    private val ctx: Context,
    private val wm: WindowManager,
    title: String,
    url: String,
    private val screenW: Int,
    private val screenH: Int,
    widthPct: Int,
    private val prefs: Prefs,
    html: String?,
    private val script: String?,
    private val onClosed: () -> Unit
) {
    private fun dp(v: Int) = Ui.dp(ctx, v)
    private var closed = false
    private var injected = false
    private val chipViews = mutableListOf<TextView>()

    private val web = WebView(ctx).apply {
        setBackgroundColor(Ui.BG)
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                // satu kali: jalankan skrip pelampir gambar setelah halaman pertama selesai dimuat
                if (script != null && !injected && url != null && url.startsWith("http")) {
                    injected = true
                    view.evaluateJavascript(script, null)
                }
            }
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val s = request.url.scheme
                return s != "http" && s != "https"
            }
        }
    }

    private inner class Root : FrameLayout(ctx) {
        override fun dispatchKeyEvent(e: KeyEvent): Boolean {
            if (e.keyCode == KeyEvent.KEYCODE_BACK) {
                if (e.action == KeyEvent.ACTION_UP) { if (web.canGoBack()) web.goBack() else close() }
                return true
            }
            return super.dispatchKeyEvent(e)
        }
    }

    private val root = Root()

    private val lp: LP = run {
        val w = (screenW * widthPct / 100f).toInt()
        val h = (screenH * 0.5f).toInt() // ~50% layar supaya keyboard tidak menutupi kolom ketik
        LP(
            w, h, LP.TYPE_APPLICATION_OVERLAY,
            LP.FLAG_NOT_TOUCH_MODAL or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS or
                LP.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (screenW - w) / 2
            y = (screenH * 0.05f).toInt()
            softInputMode = LP.SOFT_INPUT_ADJUST_NOTHING
        }
    }

    init {
        root.background = Ui.round(Ui.CARD, dp(16), Ui.STROKE)
        root.clipToOutline = true

        val column = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val header = LinearLayout(ctx).apply {
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Ui.CARD2)
        }
        header.addView(
            TextView(ctx).apply {
                text = title; textSize = 13f; setTextColor(Ui.TEXT); typeface = Typeface.DEFAULT_BOLD
                maxLines = 1; setPadding(dp(14), 0, dp(6), 0); gravity = Gravity.CENTER_VERTICAL
                setOnTouchListener(dragListener())
            },
            LinearLayout.LayoutParams(0, dp(36), 1f)
        )
        for (p in Prefs.WEB_ALPHA) {
            val c = TextView(ctx).apply {
                text = "$p%"; textSize = 10.5f; gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(dp(38), dp(36))
                setOnClickListener { applyAlpha(p) }
            }
            chipViews.add(c)
            header.addView(c)
        }
        header.addView(headerBtn("⟳", Ui.SUB) { web.reload() })
        header.addView(headerBtn("✕", Ui.BAD) { close() })
        column.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36)))
        column.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(column, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val handle = TextView(ctx).apply {
            text = "◢"; textSize = 16f; setTextColor(Ui.SUB); gravity = Gravity.CENTER
            setBackgroundColor(0x66000000)
            setOnTouchListener(resizeListener())
        }
        root.addView(handle, FrameLayout.LayoutParams(dp(34), dp(34), Gravity.BOTTOM or Gravity.END))

        applyAlpha(prefs.webAlphaPct)
        root.alpha = 0f
        wm.addView(root, lp)
        root.animate().alpha(1f).setDuration(160).start()
        if (html != null) web.loadDataWithBaseURL("https://www.google.com/", html, "text/html", "utf-8", null)
        else web.loadUrl(url)
    }

    /** Sembunyikan sementara (mis. saat screenshot agar jendela tidak ikut terfoto). */
    fun setShown(v: Boolean) { root.visibility = if (v) View.VISIBLE else View.INVISIBLE }

    /** Transparansi isi jendela; header tetap jelas supaya kontrolnya selalu terlihat. */
    private fun applyAlpha(p: Int) {
        prefs.webAlphaPct = p
        val a = p / 100f
        web.alpha = a
        root.background.alpha = (255 * a).toInt()
        Prefs.WEB_ALPHA.forEachIndexed { i, v ->
            val sel = v == p
            chipViews[i].setTextColor(if (sel) Ui.ACCENT else Ui.SUB)
            chipViews[i].typeface = if (sel) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
    }

    private fun headerBtn(t: String, color: Int, onClick: () -> Unit) = TextView(ctx).apply {
        text = t; textSize = 15f; setTextColor(color); gravity = Gravity.CENTER
        layoutParams = LinearLayout.LayoutParams(dp(38), dp(36))
        setOnClickListener { onClick() }
    }

    private fun update() { runCatching { wm.updateViewLayout(root, lp) } }

    private fun dragListener() = object : View.OnTouchListener {
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = (sx + e.rawX - dx).toInt().coerceIn(-lp.width + dp(80), screenW - dp(80))
                    lp.y = (sy + e.rawY - dy).toInt().coerceIn(0, screenH - dp(48))
                    update()
                }
            }
            return true
        }
    }

    private fun resizeListener() = object : View.OnTouchListener {
        var dx = 0f; var dy = 0f; var ow = 0; var oh = 0
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; ow = lp.width; oh = lp.height }
                MotionEvent.ACTION_MOVE -> {
                    lp.width = (ow + e.rawX - dx).toInt().coerceIn(dp(220), (screenW - lp.x).coerceAtLeast(dp(220)))
                    lp.height = (oh + e.rawY - dy).toInt().coerceIn(dp(260), (screenH - lp.y).coerceAtLeast(dp(260)))
                    update()
                }
            }
            return true
        }
    }

    fun close() {
        if (closed) return
        closed = true
        runCatching { wm.removeView(root) }
        (web.parent as? ViewGroup)?.removeView(web)
        web.stopLoading()
        web.destroy()
        onClosed()
    }
}
