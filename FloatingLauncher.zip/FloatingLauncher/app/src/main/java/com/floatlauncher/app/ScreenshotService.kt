package com.floatlauncher.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.view.Display
import android.view.accessibility.AccessibilityEvent

/**
 * Layanan Aksesibilitas yang HANYA dipakai untuk takeScreenshot() (Android 11+).
 * Diaktifkan sekali di Pengaturan; setelah itu tidak ada pop-up izin lagi.
 */
class ScreenshotService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ScreenshotService? = null
            private set
    }

    override fun onServiceConnected() { instance = this }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** Hasil dikirim di main thread; null jika gagal. */
    fun capture(cb: (Bitmap?) -> Unit) {
        if (Build.VERSION.SDK_INT < 30) {
            cb(null)
            return
        }
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                val bmp = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                    ?.copy(Bitmap.Config.ARGB_8888, false)
                result.hardwareBuffer.close()
                cb(bmp)
            }

            override fun onFailure(errorCode: Int) { cb(null) }
        })
    }
}
