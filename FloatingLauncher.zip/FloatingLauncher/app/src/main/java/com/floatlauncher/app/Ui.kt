package com.floatlauncher.app

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable

object Ui {
    val BG = 0xFF0D1015.toInt()
    val CARD = 0xFF171B23.toInt()
    val CARD2 = 0xFF222835.toInt()
    val STROKE = 0xFF2B3140.toInt()
    val ACCENT = 0xFF5B9DFF.toInt()
    val TEXT = 0xFFEDEFF4.toInt()
    val SUB = 0xFF8D95A8.toInt()
    val GOOD = 0xFF4ADE80.toInt()
    val BAD = 0xFFFF6B6B.toInt()

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    fun round(color: Int, radius: Int, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            if (stroke != 0) setStroke(1, stroke)
        }

    fun pressable(radius: Int): StateListDrawable = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), round(0x33FFFFFF, radius))
        addState(intArrayOf(), round(Color.TRANSPARENT, radius))
    }
}
