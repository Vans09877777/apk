package com.floatlauncher.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Tombol bulat melayang (digambar manual, tanpa aset gambar). */
class FloatButton(ctx: Context) : View(ctx) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.CARD2 }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Ui.ACCENT
        style = Paint.Style.STROKE
        strokeWidth = Ui.dp(ctx, 2).toFloat()
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.TEXT }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(width, height) / 2f - ring.strokeWidth
        c.drawCircle(cx, cy, r, fill)
        c.drawCircle(cx, cy, r, ring)
        val o = r * 0.3f
        val dr = r * 0.14f
        for (sx in intArrayOf(-1, 1)) for (sy in intArrayOf(-1, 1)) c.drawCircle(cx + sx * o, cy + sy * o, dr, dot)
    }
}

/**
 * View 1x1 px dengan FLAG_WATCH_OUTSIDE_TOUCH: menerima ACTION_OUTSIDE setiap kali
 * layar disentuh di luar jendelanya (tanpa menghalangi sentuhan ke aplikasi lain).
 */
class OutsideTouchView(ctx: Context, private val onOutside: () -> Unit) : View(ctx) {
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.action == MotionEvent.ACTION_OUTSIDE) onOutside()
        return true
    }
}

class MaxHeightScrollView(ctx: Context, private val maxH: Int) : ScrollView(ctx) {
    override fun onMeasure(w: Int, h: Int) {
        super.onMeasure(w, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
    }
}

/** Panel floating menu berisi ikon + nama aplikasi. */
class MenuPanel(
    ctx: Context,
    apps: List<AppInfo>,
    widthPx: Int,
    maxHeightPx: Int,
    canHide: Boolean,
    private val onOutside: () -> Unit,
    onApp: (AppInfo) -> Unit,
    onSettings: () -> Unit,
    onHide: () -> Unit
) : LinearLayout(ctx) {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private fun dp(v: Int) = Ui.dp(context, v)

    init {
        orientation = LinearLayout.VERTICAL
        background = Ui.round(Ui.CARD, dp(22), Ui.STROKE)
        setPadding(dp(12), dp(12), dp(12), dp(12))

        val header = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))
        header.addView(chip("Pengaturan", Ui.ACCENT, onSettings), chipLp())
        if (canHide) header.addView(chip("Sembunyikan", Ui.SUB, onHide), chipLp())
        addView(header, LinearLayout.LayoutParams(MATCH, WRAP))

        if (apps.isEmpty()) {
            addView(
                TextView(ctx).apply {
                    text = "Belum ada aplikasi"
                    textSize = 13f; setTextColor(Ui.SUB); setPadding(0, dp(16), 0, dp(8))
                }
            )
        } else {
            val cols = if (widthPx >= dp(270)) 4 else 3
            val cellW = (widthPx - dp(24)) / cols
            val grid = GridLayout(ctx).apply { columnCount = cols }
            for (a in apps) {
                grid.addView(cell(a, onApp), GridLayout.LayoutParams().apply { width = cellW; height = WRAP })
            }
            val scroll = MaxHeightScrollView(ctx, maxHeightPx).apply {
                isVerticalScrollBarEnabled = false
                overScrollMode = View.OVER_SCROLL_NEVER
                addView(grid)
            }
            addView(scroll, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        }
    }

    private fun chipLp() = LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(6) }

    private fun chip(label: String, color: Int, onClick: () -> Unit) = TextView(context).apply {
        text = label; textSize = 12f; setTextColor(color)
        setPadding(dp(10), dp(6), dp(10), dp(6))
        background = Ui.round(Ui.CARD2, dp(14))
        setOnClickListener { onClick() }
    }

    private fun cell(a: AppInfo, onApp: (AppInfo) -> Unit) = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(dp(4), dp(8), dp(4), dp(8))
        background = Ui.pressable(dp(14))
        addView(ImageView(context).apply { setImageDrawable(a.icon) }, LinearLayout.LayoutParams(dp(46), dp(46)))
        addView(
            TextView(context).apply {
                text = a.label; textSize = 11f; setTextColor(Ui.TEXT)
                maxLines = 1; ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER
            },
            LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) }
        )
        setOnClickListener { onApp(a) }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.action == MotionEvent.ACTION_OUTSIDE) {
            onOutside()
            return true
        }
        return super.dispatchTouchEvent(ev)
    }
}
