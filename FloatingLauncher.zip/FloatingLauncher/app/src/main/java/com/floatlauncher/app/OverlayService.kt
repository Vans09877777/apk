package com.floatlauncher.app

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.service.quicksettings.TileService
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.Toast
import kotlin.math.hypot
import kotlin.math.min

/**
 * Foreground service yang memegang semua jendela overlay (TYPE_APPLICATION_OVERLAY):
 *  - tombol melayang (bisa diseret, snap ke tepi)
 *  - panel floating menu
 *  - "sentinel" 1x1 px untuk mendeteksi ketukan layar (mode Auto Hide)
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_TOGGLE = "com.floatlauncher.app.TOGGLE"
        const val ACTION_STOP = "com.floatlauncher.app.STOP"
        private const val CHANNEL = "overlay"
        private const val NOTIF_ID = 1

        @Volatile
        var running = false
            private set
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private val handler = Handler(Looper.getMainLooper())

    private var button: FloatButton? = null
    private var btnLp: LP? = null
    private var menu: MenuPanel? = null
    private var webWin: WebWindow? = null
    private var sentinel: OutsideTouchView? = null
    private var dragging = false
    private var initialized = false
    private var lastMenuClose = 0L

    private val hideRunnable = Runnable { hideButton() }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when (key) {
            "mode", "invisible", "auto_sec" -> reconcile()
            "size_dp", "alpha_pct" -> { closeMenu(); applyAppearance() }
            "side", "y_frac" -> applyPosition()
            "apps" -> closeMenu()
        }
    }

    // ───────────────────────── lifecycle ─────────────────────────

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = Prefs(this)
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "Floating Launcher", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundCompat()
        if (intent?.action == ACTION_STOP || !Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!initialized) init()
        if (intent?.action == ACTION_TOGGLE) toggleFromTrigger()
        return START_STICKY
    }

    private fun init() {
        initialized = true
        running = true
        AppRepo.seedDefaults(this, prefs)
        prefs.sp.registerOnSharedPreferenceChangeListener(prefListener)
        reconcile()
        refreshTile()
    }

    override fun onDestroy() {
        if (initialized) prefs.sp.unregisterOnSharedPreferenceChangeListener(prefListener)
        closeMenu(false)
        webWin?.close()
        button?.let { runCatching { wm.removeView(it) } }
        button = null
        btnLp = null
        sentinel?.let { runCatching { wm.removeView(it) } }
        sentinel = null
        handler.removeCallbacksAndMessages(null)
        running = false
        refreshTile()
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        closeMenu(false)
        webWin?.close()
        applyPosition()
    }

    private fun refreshTile() {
        TileService.requestListeningState(this, ComponentName(this, OverlayTileService::class.java))
    }

    private fun startForegroundCompat() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun buildNotification(): Notification {
        fun svc(code: Int, action: String) = PendingIntent.getService(
            this, code, Intent(this, OverlayService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val icon = Icon.createWithResource(this, R.drawable.ic_notif)
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Floating Launcher aktif")
            .setContentText("Ketuk untuk membuka pengaturan")
            .setContentIntent(open)
            .setOngoing(true)
            .setShowWhen(false)
            .addAction(Notification.Action.Builder(icon, "Tampil / Sembunyi", svc(1, ACTION_TOGGLE)).build())
            .addAction(Notification.Action.Builder(icon, "Hentikan", svc(2, ACTION_STOP)).build())
            .build()
    }

    // ───────────────────────── state logic ─────────────────────────

    /** Menyelaraskan jendela overlay dengan pengaturan saat ini. */
    private fun reconcile() {
        handler.removeCallbacks(hideRunnable)
        updateSentinel()
        if (prefs.invisible) {
            hideButton()
        } else {
            showButton()
            scheduleHide()
        }
    }

    /** Auto Hide, atau Invisible (muncul sementara lewat trigger) -> sembunyi setelah N detik. */
    private fun scheduleHide() {
        handler.removeCallbacks(hideRunnable)
        val timed = prefs.mode == Prefs.MODE_AUTO || prefs.invisible
        if (timed && button != null && menu == null && !dragging) {
            handler.postDelayed(hideRunnable, prefs.autoSec * 1000L)
        }
    }

    /** Trigger dari notifikasi / Quick Settings tile. */
    private fun toggleFromTrigger() {
        if (button != null) {
            hideButton()
        } else {
            showButton()
            scheduleHide()
        }
    }

    /** Dipanggil saat layar diketuk di luar overlay (hanya aktif di mode Auto Hide). */
    private fun onScreenTouched() {
        if (button == null) {
            showButton()
            scheduleHide()
        }
    }

    private fun onButtonLongPress() {
        if (prefs.mode != Prefs.MODE_ALWAYS || prefs.invisible) {
            button?.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            hideButton()
        }
    }

    private fun updateSentinel() {
        val need = prefs.mode == Prefs.MODE_AUTO && !prefs.invisible
        if (need && sentinel == null) {
            val v = OutsideTouchView(this) { onScreenTouched() }
            val lp = LP(
                1, 1, LP.TYPE_APPLICATION_OVERLAY,
                LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCH_MODAL or LP.FLAG_WATCH_OUTSIDE_TOUCH,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START }
            runCatching { wm.addView(v, lp); sentinel = v }
        } else if (!need) {
            sentinel?.let { runCatching { wm.removeView(it) } }
            sentinel = null
        }
    }

    // ───────────────────────── floating button ─────────────────────────

    private fun showButton() {
        button?.let { b ->
            b.animate().cancel()
            b.animate().alpha(prefs.alphaPct / 100f).scaleX(1f).scaleY(1f).setDuration(180).start()
            return
        }
        val size = Ui.dp(this, prefs.sizeDp)
        val lp = LP(
            size, size, LP.TYPE_APPLICATION_OVERLAY,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        val (x, y) = posFromPrefs(size)
        lp.x = x
        lp.y = y
        val b = FloatButton(this).apply {
            alpha = 0f; scaleX = 0.6f; scaleY = 0.6f
            setOnTouchListener(ButtonTouch())
        }
        try {
            wm.addView(b, lp)
        } catch (e: Exception) {
            stopSelf()
            return
        }
        button = b
        btnLp = lp
        b.animate().alpha(prefs.alphaPct / 100f).scaleX(1f).scaleY(1f)
            .setDuration(220).setInterpolator(OvershootInterpolator(1.2f)).start()
    }

    private fun hideButton() {
        handler.removeCallbacks(hideRunnable)
        closeMenu()
        dragging = false
        val b = button ?: return
        button = null
        btnLp = null
        b.setOnTouchListener(null)
        b.animate().cancel()
        b.animate().alpha(0f).scaleX(0.6f).scaleY(0.6f).setDuration(180)
            .withEndAction { runCatching { wm.removeView(b) } }.start()
    }

    private fun applyAppearance() {
        val b = button ?: return
        val lp = btnLp ?: return
        val size = Ui.dp(this, prefs.sizeDp)
        lp.width = size
        lp.height = size
        b.alpha = prefs.alphaPct / 100f
        applyPosition()
    }

    private fun applyPosition() {
        val b = button ?: return
        val lp = btnLp ?: return
        val (x, y) = posFromPrefs(lp.width)
        lp.x = x
        lp.y = y
        runCatching { wm.updateViewLayout(b, lp) }
    }

    private fun posFromPrefs(size: Int): Pair<Int, Int> {
        val s = screen()
        val x = if (prefs.side == 0) 0 else (s.x - size).coerceAtLeast(0)
        val maxY = (s.y - size).coerceAtLeast(1)
        val y = (prefs.yFrac * maxY).toInt().coerceIn(0, maxY)
        return x to y
    }

    @Suppress("DEPRECATION")
    private fun screen(): Point {
        val p = Point()
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            p.set(b.width(), b.height())
        } else {
            wm.defaultDisplay.getRealSize(p)
        }
        return p
    }

    /** Setelah dilepas: tempel ke tepi kiri/kanan terdekat dengan animasi, lalu simpan posisi. */
    private fun snap() {
        val b = button ?: return
        val lp = btnLp ?: return
        val s = screen()
        val size = lp.width
        val toRight = lp.x + size / 2 >= s.x / 2
        val targetX = if (toRight) (s.x - size).coerceAtLeast(0) else 0
        val maxY = (s.y - size).coerceAtLeast(1)
        lp.y = lp.y.coerceIn(0, maxY)
        ValueAnimator.ofInt(lp.x, targetX).apply {
            duration = 180
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                lp.x = it.animatedValue as Int
                if (button === b) runCatching { wm.updateViewLayout(b, lp) }
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    prefs.savePosition(if (toRight) 1 else 0, lp.y / maxY.toFloat())
                }
            })
            start()
        }
    }

    private inner class ButtonTouch : View.OnTouchListener {
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0
        private var moved = false
        private var longFired = false
        private var menuWasOpen = false
        private var scr = Point()
        private val slop = ViewConfiguration.get(this@OverlayService).scaledTouchSlop
        private val longPress = Runnable { longFired = true; onButtonLongPress() }

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            val lp = btnLp ?: return false
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = lp.x; startY = lp.y
                    moved = false; longFired = false; dragging = true
                    // sentuhan pada tombol juga dihitung "di luar" panel menu -> bedakan toggle
                    menuWasOpen = menu != null || SystemClock.uptimeMillis() - lastMenuClose < 250
                    scr = screen()
                    handler.removeCallbacks(hideRunnable)
                    handler.postDelayed(longPress, ViewConfiguration.getLongPressTimeout().toLong())
                    v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(80).start()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!moved && hypot(dx, dy) > slop) {
                        moved = true
                        handler.removeCallbacks(longPress)
                        closeMenu()
                    }
                    if (moved) {
                        lp.x = (startX + dx).toInt().coerceIn(0, (scr.x - lp.width).coerceAtLeast(0))
                        lp.y = (startY + dy).toInt().coerceIn(0, (scr.y - lp.height).coerceAtLeast(0))
                        runCatching { wm.updateViewLayout(v, lp) }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longPress)
                    dragging = false
                    v.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
                    if (moved) {
                        snap()
                    } else if (e.actionMasked == MotionEvent.ACTION_UP && !longFired) {
                        if (menuWasOpen) closeMenu() else openMenu()
                    }
                    scheduleHide()
                }
            }
            return true
        }
    }

    // ───────────────────────── floating menu ─────────────────────────

    private fun openMenu() {
        val bl = btnLp ?: return
        if (menu != null) return
        handler.removeCallbacks(hideRunnable)

        val s = screen()
        val size = bl.width
        val gap = Ui.dp(this, 8)
        val panelW = min(Ui.dp(this, 320), s.x - size - Ui.dp(this, 24)).coerceAtLeast(Ui.dp(this, 220))
        val apps = prefs.apps.mapNotNull { AppRepo.resolve(this, it) }
        val canHide = prefs.mode != Prefs.MODE_ALWAYS || prefs.invisible

        val panel = MenuPanel(
            this, apps, panelW, min((s.y * 0.55f).toInt(), Ui.dp(this, 380)), canHide,
            onOutside = { closeMenu() },
            onApp = { launchApp(it) },
            onSettings = {
                closeMenu()
                startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            },
            onHide = { closeMenu(); hideButton() }
        )
        panel.measure(
            View.MeasureSpec.makeMeasureSpec(panelW, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(s.y, View.MeasureSpec.AT_MOST)
        )
        val h = panel.measuredHeight
        val onLeft = bl.x + size / 2 < s.x / 2
        val margin = Ui.dp(this, 4)
        val px = (if (onLeft) bl.x + size + gap else bl.x - panelW - gap)
            .coerceIn(margin, (s.x - panelW - margin).coerceAtLeast(margin))
        val py = bl.y.coerceIn(Ui.dp(this, 24), (s.y - h - Ui.dp(this, 24)).coerceAtLeast(Ui.dp(this, 24)))

        val lp = LP(
            panelW, LP.WRAP_CONTENT, LP.TYPE_APPLICATION_OVERLAY,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCH_MODAL or LP.FLAG_WATCH_OUTSIDE_TOUCH or
                LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = px; y = py }

        panel.alpha = 0f
        panel.scaleX = 0.85f
        panel.scaleY = 0.85f
        panel.pivotX = if (onLeft) 0f else panelW.toFloat()
        panel.pivotY = (bl.y + size / 2 - py).toFloat().coerceIn(0f, h.toFloat())
        try {
            wm.addView(panel, lp)
        } catch (e: Exception) {
            return
        }
        menu = panel
        panel.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(160).start()
    }

    private fun closeMenu(animated: Boolean = true) {
        val m = menu ?: return
        menu = null
        lastMenuClose = SystemClock.uptimeMillis()
        m.animate().cancel()
        if (animated) {
            m.animate().alpha(0f).scaleX(0.9f).scaleY(0.9f).setDuration(120)
                .withEndAction { runCatching { wm.removeView(m) } }.start()
        } else {
            runCatching { wm.removeView(m) }
        }
        scheduleHide()
    }

    private fun openWebWindow(title: String, url: String, html: String? = null, script: String? = null) {
        webWin?.close()
        val s = screen()
        webWin = try {
            WebWindow(
                this, wm, title.removeSuffix(" (jendela)"), url, s.x, s.y,
                prefs.floatSizePct, prefs, html, script
            ) { webWin = null }
        } catch (e: Exception) {
            Toast.makeText(this, "Tidak bisa membuka jendela web", Toast.LENGTH_SHORT).show()
            null
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    /** Screenshot layar -> kirim ke jendela floating Google (Lens) atau ChatGPT. */
    private fun askAboutScreen(target: String) {
        if (Build.VERSION.SDK_INT < 30) {
            toast("Fitur SS butuh Android 11 ke atas")
            return
        }
        val svc = ScreenshotService.instance
        if (svc == null) {
            toast("Aktifkan layanan Screenshot dulu")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
        // sembunyikan overlay kita supaya tidak ikut terfoto
        val b = button
        val w = webWin
        b?.visibility = View.INVISIBLE
        w?.setShown(false)
        handler.postDelayed({
            svc.capture { bmp ->
                b?.visibility = View.VISIBLE
                w?.setShown(true)
                if (bmp == null) {
                    toast("Gagal mengambil screenshot")
                    return@capture
                }
                Thread {
                    val b64 = ScreenAsk.encode(bmp)
                    handler.post {
                        if (target == "google") {
                            openWebWindow("Google", "https://www.google.com/", ScreenAsk.googleHtml(b64), null)
                        } else {
                            openWebWindow("ChatGPT", "https://chatgpt.com/", null, ScreenAsk.chatGptScript(b64))
                        }
                    }
                }.start()
            }
        }, 260)
    }

    private fun launchApp(a: AppInfo) {
        closeMenu()
        if (AppRepo.isShot(a.pkg)) {
            askAboutScreen(if (a.pkg == "shot:google") "google" else "chatgpt")
            return
        }
        val url = AppRepo.webUrl(a.pkg)
        if (url != null) {
            openWebWindow(a.label, url)
            return
        }
        if (!AppRepo.launch(this, a.pkg)) {
            Toast.makeText(this, "Tidak bisa membuka ${a.label}", Toast.LENGTH_SHORT).show()
        }
    }
}
