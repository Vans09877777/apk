package com.floatlauncher.app

import android.content.Context

/** Semua pengaturan disimpan di SharedPreferences (ringan, tanpa dependensi). */
class Prefs(ctx: Context) {
    companion object {
        const val MODE_ALWAYS = 0
        const val MODE_AUTO = 1
        const val MODE_MANUAL = 2
        val AUTO_OPTIONS = listOf(3, 5, 7, 10)
        val WEB_ALPHA = listOf(100, 50, 30, 10)
    }

    val sp = ctx.applicationContext.getSharedPreferences("overlay_prefs", Context.MODE_PRIVATE)

    var mode: Int
        get() = sp.getInt("mode", MODE_ALWAYS)
        set(v) { sp.edit().putInt("mode", v).apply() }

    var invisible: Boolean
        get() = sp.getBoolean("invisible", false)
        set(v) { sp.edit().putBoolean("invisible", v).apply() }

    var autoSec: Int
        get() = sp.getInt("auto_sec", 5).let { if (it in AUTO_OPTIONS) it else 5 }
        set(v) { sp.edit().putInt("auto_sec", v).apply() }

    var sizeDp: Int
        get() = sp.getInt("size_dp", 52)
        set(v) { sp.edit().putInt("size_dp", v).apply() }

    var alphaPct: Int
        get() = sp.getInt("alpha_pct", 85)
        set(v) { sp.edit().putInt("alpha_pct", v).apply() }

    /** 0 = kiri, 1 = kanan */
    var side: Int
        get() = sp.getInt("side", 1)
        set(v) { sp.edit().putInt("side", v).apply() }

    /** Posisi vertikal 0f..1f (relatif terhadap tinggi layar, aman saat rotasi) */
    var yFrac: Float
        get() = sp.getFloat("y_frac", 0.4f)
        set(v) { sp.edit().putFloat("y_frac", v.coerceIn(0f, 1f)).apply() }

    /** Daftar package name aplikasi di floating menu, berurutan. */
    var apps: List<String>
        get() = (sp.getString("apps", "") ?: "").split(",").filter { it.isNotBlank() }
        set(v) { sp.edit().putString("apps", v.joinToString(",")).apply() }

    /** Buka aplikasi sebagai jendela floating (freeform) bila didukung perangkat. */
    var floatApps: Boolean
        get() = sp.getBoolean("float_apps", true)
        set(v) { sp.edit().putBoolean("float_apps", v).apply() }

    /** Lebar jendela aplikasi floating, persen dari lebar layar. */
    var floatSizePct: Int
        get() = sp.getInt("float_size", 85)
        set(v) { sp.edit().putInt("float_size", v).apply() }

    /** Transparansi jendela Google/ChatGPT: 100, 50, 30, atau 10 (%). */
    var webAlphaPct: Int
        get() = sp.getInt("web_alpha", 100).let { if (it in WEB_ALPHA) it else 100 }
        set(v) { sp.edit().putInt("web_alpha", v).apply() }

    fun savePosition(side: Int, y: Float) {
        sp.edit().putInt("side", side).putFloat("y_frac", y.coerceIn(0f, 1f)).apply()
    }
}
