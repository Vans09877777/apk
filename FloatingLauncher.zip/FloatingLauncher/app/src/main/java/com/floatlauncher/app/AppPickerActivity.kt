package com.floatlauncher.app

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

/** Add App: pilih aplikasi apa pun yang terpasang di HP. Ketuk untuk menambah / menghapus. */
class AppPickerActivity : Activity() {

    private lateinit var prefs: Prefs
    private var all: List<AppInfo> = emptyList()
    private var shown: List<AppInfo> = emptyList()
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private fun dp(v: Int) = Ui.dp(this, v)

    private class Row(
        val view: LinearLayout, val icon: ImageView, val name: TextView, val pkg: TextView, val mark: TextView
    )

    private val adapter = object : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(position: Int) = shown[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val r = (convertView?.tag as? Row) ?: newRow().also { it.view.tag = it }
            val a = shown[position]
            val added = a.pkg in prefs.apps
            r.icon.setImageDrawable(a.icon)
            r.name.text = a.label
            r.pkg.text = when {
                AppRepo.isWeb(a.pkg) -> "Jendela floating (web)"
                AppRepo.isShot(a.pkg) -> "Screenshot layar → jawaban"
                else -> a.pkg
            }
            r.mark.text = if (added) "✓" else "+"
            r.mark.setTextColor(if (added) Ui.GOOD else Ui.SUB)
            return r.view
        }
    }

    private fun newRow(): Row {
        val view = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = Ui.pressable(dp(12))
        }
        val icon = ImageView(this)
        view.addView(icon, LinearLayout.LayoutParams(dp(40), dp(40)))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val name = TextView(this).apply {
            textSize = 15f; setTextColor(Ui.TEXT); maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }
        val pkg = TextView(this).apply {
            textSize = 11f; setTextColor(Ui.SUB); maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }
        col.addView(name)
        col.addView(pkg)
        view.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(12); marginEnd = dp(8) })
        val mark = TextView(this).apply { textSize = 20f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD }
        view.addView(mark, LinearLayout.LayoutParams(dp(36), dp(36)))
        return Row(view, icon, name, pkg, mark)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
            setPadding(dp(16), dp(20), dp(16), dp(8))
        }

        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(
            TextView(this).apply {
                text = "Tambah Aplikasi"; textSize = 22f; setTextColor(Ui.TEXT); typeface = Typeface.DEFAULT_BOLD
            },
            LinearLayout.LayoutParams(0, WRAP, 1f)
        )
        header.addView(
            TextView(this).apply {
                text = "Selesai"; textSize = 14f; setTextColor(Color.WHITE)
                setPadding(dp(16), dp(8), dp(16), dp(8))
                background = Ui.round(Ui.ACCENT, dp(16))
                setOnClickListener { finish() }
            }
        )
        root.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))

        val search = EditText(this).apply {
            hint = "Cari aplikasi…"
            setHintTextColor(Ui.SUB)
            setTextColor(Ui.TEXT)
            isSingleLine = true
            textSize = 14f
            background = Ui.round(Ui.CARD, dp(14), Ui.STROKE)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) = applyFilter(s?.toString().orEmpty())
            })
        }
        root.addView(search, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14); bottomMargin = dp(8) })

        val empty = TextView(this).apply {
            text = "Memuat aplikasi…"; textSize = 13f; setTextColor(Ui.SUB); gravity = Gravity.CENTER
            setPadding(0, dp(32), 0, 0)
        }
        val list = ListView(this).apply {
            divider = null
            selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            adapter = this@AppPickerActivity.adapter
            emptyView = empty
            onItemClickListener = AdapterView.OnItemClickListener { _, _, pos, _ -> toggle(shown[pos]) }
        }
        root.addView(list, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(empty, LinearLayout.LayoutParams(MATCH, WRAP))
        setContentView(root)

        // Memuat ikon+label puluhan aplikasi dilakukan di background thread.
        Thread {
            val apps = AppRepo.launchable(this)
            runOnUiThread {
                all = apps
                empty.text = "Tidak ada hasil"
                applyFilter(search.text.toString())
            }
        }.start()
    }

    private fun applyFilter(q: String) {
        shown = if (q.isBlank()) all else all.filter { it.label.contains(q.trim(), ignoreCase = true) }
        adapter.notifyDataSetChanged()
    }

    private fun toggle(a: AppInfo) {
        val l = prefs.apps.toMutableList()
        if (!l.remove(a.pkg)) l.add(a.pkg)
        prefs.apps = l
        adapter.notifyDataSetChanged()
    }
}
