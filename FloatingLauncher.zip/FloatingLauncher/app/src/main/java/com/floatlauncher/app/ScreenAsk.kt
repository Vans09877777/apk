package com.floatlauncher.app

import android.graphics.Bitmap
import android.util.Base64
import org.json.JSONObject
import java.io.ByteArrayOutputStream

/** Menyiapkan screenshot untuk dikirim ke halaman web Google (Lens) atau ChatGPT. */
object ScreenAsk {
    const val PROMPT = "Jawab soal atau pertanyaan di gambar ini dengan singkat dan jelas."

    /** Perkecil + JPEG + base64 supaya ringan. */
    fun encode(src: Bitmap): String {
        val maxW = 1080
        val bmp = if (src.width > maxW) {
            Bitmap.createScaledBitmap(src, maxW, (src.height * maxW.toFloat() / src.width).toInt(), true)
        } else src
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    /** Halaman kecil yang mengirim gambar ke pencarian gambar Google (Lens) lewat form upload. */
    fun googleHtml(b64: String): String = """
<html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;background:#0D1015;color:#8D95A8;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh">
<form id="f" method="POST" action="https://www.google.com/searchbyimage/upload" enctype="multipart/form-data">
<input type="file" name="encoded_image" id="i" style="display:none"></form>
<div>Mengirim ke Google…</div>
<script>
(function(){
  var bin=atob("__B64__"),n=bin.length,u=new Uint8Array(n);
  for(var k=0;k<n;k++)u[k]=bin.charCodeAt(k);
  var dt=new DataTransfer();
  dt.items.add(new File([u],"screenshot.jpg",{type:"image/jpeg"}));
  document.getElementById("i").files=dt.files;
  document.getElementById("f").submit();
})();
</script></body></html>
""".replace("__B64__", b64)

    /** JS: melampirkan gambar ke ChatGPT, mengisi pertanyaan, lalu menekan kirim (mencoba ~40 detik). */
    fun chatGptScript(b64: String): String = """
(function(){
  var prompt=__PROMPT__, tries=0, attached=false, typed=false;
  function mk(){var bin=atob("__B64__"),n=bin.length,u=new Uint8Array(n);
    for(var i=0;i<n;i++)u[i]=bin.charCodeAt(i);
    return new File([u],"screenshot.jpg",{type:"image/jpeg"});}
  var t=setInterval(function(){
    if(++tries>60){clearInterval(t);return;}
    if(!attached){
      var ins=[].slice.call(document.querySelectorAll("input[type=file]"));
      var inp=ins.filter(function(x){return (x.accept||"").indexOf("image")>=0})[0]||ins[0];
      if(inp){var dt=new DataTransfer();dt.items.add(mk());inp.files=dt.files;
        inp.dispatchEvent(new Event("change",{bubbles:true}));attached=true;}
      return;
    }
    if(!typed){
      var box=document.querySelector("#prompt-textarea");
      if(box){box.focus();document.execCommand("insertText",false,prompt);typed=true;}
      return;
    }
    var btn=document.querySelector('[data-testid="send-button"]');
    if(btn&&!btn.disabled){btn.click();clearInterval(t);}
  },700);
})();
""".replace("__B64__", b64).replace("__PROMPT__", JSONObject.quote(PROMPT))
}
