package com.floatlauncher.app

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable

data class AppInfo(val pkg: String, val label: String, val icon: Drawable)

@Suppress("DEPRECATION")
object AppRepo {
    // Google, Gemini, ChatGPT: ditambahkan otomatis jika terpasang
    private val DEFAULTS = listOf(
        "com.google.android.googlequicksearchbox",
        "com.google.android.apps.bard",
        "com.openai.chatgpt"
    )

    /** Semua aplikasi terpasang yang punya ikon launcher (untuk Add App). */
    fun launchable(ctx: Context): List<AppInfo> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { AppInfo(it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
            .sortedBy { it.label.lowercase() }
    }

    /** Ikon + nama aplikasi otomatis dari PackageManager; null jika sudah tidak terpasang. */
    fun resolve(ctx: Context, pkg: String): AppInfo? {
        val pm = ctx.packageManager
        if (pm.getLaunchIntentForPackage(pkg) == null) return null
        return try {
            val ai = pm.getApplicationInfo(pkg, 0)
            AppInfo(pkg, pm.getApplicationLabel(ai).toString(), pm.getApplicationIcon(ai))
        } catch (e: PackageManager.NameNotFoundException) {
            null
        }
    }

    fun launch(ctx: Context, pkg: String): Boolean {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { ctx.startActivity(i); true } catch (e: Exception) { false }
    }

    fun seedDefaults(ctx: Context, prefs: Prefs) {
        if (prefs.sp.contains("apps")) return
        prefs.apps = DEFAULTS.filter { ctx.packageManager.getLaunchIntentForPackage(it) != null }
    }
}
