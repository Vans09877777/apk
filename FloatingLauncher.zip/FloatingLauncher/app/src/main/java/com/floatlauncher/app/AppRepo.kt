package com.floatlauncher.app

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Rect
import android.graphics.drawable.Drawable

data class AppInfo(val pkg: String, val label: String, val icon: Drawable)

/** Entri "jendela web": dibuka di jendela floating buatan sendiri (tanpa Opsi Pengembang). */
data class WebApp(val label: String, val url: String, val letter: String, val color: Int)

@Suppress("DEPRECATION")
object AppRepo {
    // Google, Gemini, ChatGPT: ditambahkan otomatis jika terpasang
    val WEB = linkedMapOf(
        "web:google" to WebApp("Google (jendela)", "https://www.google.com/", "G", 0xFF4285F4.toInt()),
        "web:chatgpt" to WebApp("ChatGPT (jendela)", "https://chatgpt.com/", "C", 0xFF10A37F.toInt())
    )

    /** Entri "SS": ambil screenshot layar lalu kirim ke jendela Google / ChatGPT. */
    val SHOT = linkedMapOf(
        "shot:google" to WebApp("SS Google", "", "◎", 0xFF4285F4.toInt()),
        "shot:chatgpt" to WebApp("SS ChatGPT", "", "◎", 0xFF10A37F.toInt())
    )

    fun isWeb(pkg: String) = pkg.startsWith("web:")
    fun isShot(pkg: String) = pkg.startsWith("shot:")
    fun webUrl(pkg: String): String? = WEB[pkg]?.url
    private fun webInfo(key: String, w: WebApp) = AppInfo(key, w.label, LetterIcon(w.letter, w.color))

    private val DEFAULTS = listOf(
        "com.google.android.googlequicksearchbox",
        "com.google.android.apps.bard",
        "com.openai.chatgpt"
    )

    /** Semua aplikasi terpasang yang punya ikon launcher (untuk Add App). */
    fun launchable(ctx: Context): List<AppInfo> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val installed = pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { AppInfo(it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
            .sortedBy { it.label.lowercase() }
        return (WEB + SHOT).map { (k, v) -> webInfo(k, v) } + installed
    }

    /** Ikon + nama aplikasi otomatis dari PackageManager; null jika sudah tidak terpasang. */
    fun resolve(ctx: Context, pkg: String): AppInfo? {
        if (isWeb(pkg)) return WEB[pkg]?.let { webInfo(pkg, it) }
        if (isShot(pkg)) return SHOT[pkg]?.let { webInfo(pkg, it) }
        val pm = ctx.packageManager
        if (pm.getLaunchIntentForPackage(pkg) == null) return null
        return try {
            val ai = pm.getApplicationInfo(pkg, 0)
            AppInfo(pkg, pm.getApplicationLabel(ai).toString(), pm.getApplicationIcon(ai))
        } catch (e: PackageManager.NameNotFoundException) {
            null
        }
    }

    /**
     * Membuka aplikasi. Jika [bounds] diberikan, aplikasi diminta tampil sebagai jendela
     * floating (freeform) dengan ukuran/posisi tsb. Android hanya menurutinya bila
     * "freeform windows" aktif di perangkat; jika tidak, aplikasi terbuka layar penuh seperti biasa.
     */
    fun launch(ctx: Context, pkg: String, bounds: Rect? = null): Boolean {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            if (bounds != null) {
                val opts = ActivityOptions.makeBasic().setLaunchBounds(bounds)
                ctx.startActivity(i, opts.toBundle())
            } else {
                ctx.startActivity(i)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun seedDefaults(ctx: Context, prefs: Prefs) {
        if (!prefs.sp.contains("apps")) {
            prefs.apps = DEFAULTS.filter { ctx.packageManager.getLaunchIntentForPackage(it) != null }
        }
        // sekali saja: tambahkan entri jendela web ke menu (juga untuk pengguna versi lama)
        if (!prefs.sp.getBoolean("web_seeded", false)) {
            val cur = prefs.apps
            prefs.apps = cur + WEB.keys.filter { it !in cur }
            prefs.sp.edit().putBoolean("web_seeded", true).apply()
        }
        if (!prefs.sp.getBoolean("shot_seeded", false)) {
            val cur = prefs.apps
            prefs.apps = cur + SHOT.keys.filter { it !in cur }
            prefs.sp.edit().putBoolean("shot_seeded", true).apply()
        }
    }
}
