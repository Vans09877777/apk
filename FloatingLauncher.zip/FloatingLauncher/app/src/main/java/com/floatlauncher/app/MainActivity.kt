package com.floatlauncher.app

import android.Manifest
import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

/** Layar pengaturan: dibangun lewat kode, tanpa XML layout dan tanpa library UI tambahan. */
class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var root: LinearLayout
    private lateinit var statusDot: View
    private lateinit var statusText: TextView
    private lateinit var svcBtn: Button
    private lateinit var appsList: LinearLayout
    private lateinit var durationRow: LinearLayout
    private lateinit var ssText: TextView
    private lateinit var ssBtn: Button
    private val handler = Handler(Looper.getMainLooper())
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val TIKTOK_URL = "https://www.tiktok.com/@darkai.offcial"
    private val WA_CHANNEL_URL = "https://whatsapp.com/channel/0029Vb6s3KpK5cD70KdxqQ0r"

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        AppRepo.seedDefaults(this, prefs)
        setContentView(buildUi())
        if (savedInstanceState == null) showWelcome() // tampil setiap aplikasi dibuka
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        renderApps()
    }

    // ───────────────────────── Sambutan ─────────────────────────

    private fun showWelcome() {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.round(Ui.CARD, dp(22), Ui.STROKE)
            setPadding(dp(20), dp(22), dp(20), dp(14))
        }
        box.addView(label("Selamat datang 👋", 20f, Ui.TEXT, true))
        box.addView(
            label(
                "Terima kasih sudah membeli aplikasi ini!\n\n" +
                    "Mohon bantu support creator dengan mengikuti sosial medianya ya 🙏",
                14f, Ui.SUB
            ).apply { setPadding(0, dp(10), 0, dp(6)); setLineSpacing(dp(3).toFloat(), 1f) }
        )
        box.addView(button("Ikuti TikTok @darkai.offcial", true) { openUrl(TIKTOK_URL) }, btnLp())
        box.addView(button("Gabung Saluran WhatsApp", true) { openUrl(WA_CHANNEL_URL) }, btnLp())
        box.addView(
            label("Tutup", 14f, Ui.SUB).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(14), 0, dp(6))
                setOnClickListener { d.dismiss() }
            },
            LinearLayout.LayoutParams(MATCH, WRAP)
        )
        d.setContentView(box)
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.show()
        d.window?.setLayout((resources.displayMetrics.widthPixels * 0.9f).toInt(), WRAP)
    }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(this, "Tidak bisa membuka tautan", Toast.LENGTH_SHORT).show()
        }
    }

    // ───────────────────────── UI ─────────────────────────

    private fun buildUi(): View {
        val scroll = ScrollView(this).apply { setBackgroundColor(Ui.BG); isVerticalScrollBarEnabled = false }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(32))
        }
        scroll.addView(root)
        root.addView(label("Floating Launcher", 26f, Ui.TEXT, true))

        // Status
        val status = card()
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        statusDot = View(this)
        row.addView(statusDot, LinearLayout.LayoutParams(dp(10), dp(10)).apply { marginEnd = dp(10) })
        statusText = label("", 16f, Ui.TEXT, true)
        row.addView(statusText)
        status.addView(row)
        svcBtn = button("", true) { toggleService() }
        status.addView(svcBtn, btnLp())

        // Tombol
        val mode = card("Tombol")
        segmented(mode, listOf("Selalu", "Auto Hide", "Manual"), prefs.mode) {
            prefs.mode = it
            updateDurationEnabled()
        }
        mode.addView(
            Switch(this).apply {
                text = "Invisible"
                textSize = 14f
                setTextColor(Ui.TEXT)
                isChecked = prefs.invisible
                setOnCheckedChangeListener { _, c -> prefs.invisible = c; updateDurationEnabled() }
            },
            LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(16) }
        )
        mode.addView(caption("Sembunyi setelah"))
        durationRow = segmented(
            mode, Prefs.AUTO_OPTIONS.map { "$it dtk" },
            Prefs.AUTO_OPTIONS.indexOf(prefs.autoSec).coerceAtLeast(0)
        ) { prefs.autoSec = Prefs.AUTO_OPTIONS[it] }
        updateDurationEnabled()

        // Tampilan
        val look = card("Tampilan")
        slider(look, "Ukuran", 36, 80, prefs.sizeDp, " dp") { prefs.sizeDp = it }
        slider(look, "Transparansi", 20, 100, prefs.alphaPct, "%") { prefs.alphaPct = it }
        slider(look, "Posisi vertikal", 0, 100, (prefs.yFrac * 100).roundToInt(), "%") { prefs.yFrac = it / 100f }
        look.addView(caption("Sisi"))
        segmented(look, listOf("Kiri", "Kanan"), prefs.side) { prefs.side = it }

        // Jendela Google & ChatGPT
        val web = card("Jendela Google & ChatGPT")
        slider(web, "Lebar", 50, 95, prefs.floatSizePct, "%") { prefs.floatSizePct = it }
        web.addView(caption("Transparansi awal"))
        segmented(web, Prefs.WEB_ALPHA.map { "$it%" }, Prefs.WEB_ALPHA.indexOf(prefs.webAlphaPct).coerceAtLeast(0)) {
            prefs.webAlphaPct = Prefs.WEB_ALPHA[it]
        }

        // Screenshot
        val ss = card("Screenshot")
        ssText = label("", 13f, Ui.SUB).apply {
            setPadding(0, dp(8), 0, 0)
            setLineSpacing(dp(3).toFloat(), 1f)
        }
        ss.addView(ssText)
        ssBtn = button("Aktifkan", false) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        ss.addView(ssBtn, btnLp())

        // Aplikasi
        val apps = card("Aplikasi")
        appsList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        apps.addView(appsList)
        apps.addView(
            button("+ Tambah", false) { startActivity(Intent(this, AppPickerActivity::class.java)) },
            btnLp()
        )
        return scroll
    }

    private fun updateDurationEnabled() {
        val on = prefs.mode == Prefs.MODE_AUTO || prefs.invisible
        durationRow.alpha = if (on) 1f else 0.4f
        for (i in 0 until durationRow.childCount) durationRow.getChildAt(i).isEnabled = on
    }

    private fun refreshStatus() {
        val granted = Settings.canDrawOverlays(this)
        val running = OverlayService.running
        statusText.text = when {
            !granted -> "Izin overlay diperlukan"
            running -> "Aktif"
            else -> "Mati"
        }
        statusDot.background = Ui.round(
            when { !granted -> Ui.BAD; running -> Ui.GOOD; else -> Ui.SUB }, dp(5)
        )
        svcBtn.text = when {
            !granted -> "Beri izin"
            running -> "Hentikan"
            else -> "Mulai"
        }
        val ssOn = ScreenshotService.instance != null
        val ssOld = Build.VERSION.SDK_INT < 30
        ssText.text = when {
            ssOld -> "Butuh Android 11 ke atas"
            ssOn -> "Aktif ✓  Dipakai hanya saat Anda menekan SS di menu."
            else -> "Aktifkan layanan Aksesibilitas \"Floating Launcher\". Hanya dipakai saat Anda menekan SS di menu.\n" +
                "Jika tombolnya abu-abu: Info aplikasi → ⋮ → Izinkan pengaturan terbatas."
        }
        ssText.setTextColor(if (ssOn) Ui.GOOD else Ui.SUB)
        ssBtn.visibility = if (ssOn || ssOld) View.GONE else View.VISIBLE
        val stop = granted && running
        svcBtn.setTextColor(if (stop) Ui.BAD else Color.WHITE)
        svcBtn.background = Ui.round(if (stop) 0xFF3A2226.toInt() else Ui.ACCENT, dp(14))
    }

    private fun toggleService() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val i = Intent(this, OverlayService::class.java)
        if (OverlayService.running) stopService(i) else startForegroundService(i)
        handler.postDelayed({ refreshStatus() }, 400)
    }

    private fun renderApps() {
        appsList.removeAllViews()
        val list = prefs.apps
        list.forEachIndexed { i, pkg ->
            val info = AppRepo.resolve(this, pkg)
            val row = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(6), 0, dp(6))
            }
            row.addView(
                ImageView(this).apply { if (info != null) setImageDrawable(info.icon) },
                LinearLayout.LayoutParams(dp(36), dp(36))
            )
            row.addView(
                label(info?.label ?: pkg, 14f, if (info != null) Ui.TEXT else Ui.SUB).apply {
                    setPadding(dp(12), 0, dp(8), 0)
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                },
                LinearLayout.LayoutParams(0, WRAP, 1f)
            )
            row.addView(iconBtn("▲", i > 0, Ui.SUB) { move(i, i - 1) })
            row.addView(iconBtn("▼", i < list.lastIndex, Ui.SUB) { move(i, i + 1) })
            row.addView(iconBtn("✕", true, Ui.BAD) {
                prefs.apps = list.toMutableList().also { it.removeAt(i) }
                renderApps()
            })
            appsList.addView(row)
        }
    }

    private fun move(from: Int, to: Int) {
        val l = prefs.apps.toMutableList()
        if (to !in l.indices) return
        val item = l.removeAt(from)
        l.add(to, item)
        prefs.apps = l
        renderApps()
    }

    // ───────────────────────── helpers ─────────────────────────

    private fun label(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun caption(s: String) = label(s, 12f, Ui.SUB).apply { setPadding(0, dp(16), 0, 0) }

    private fun card(title: String? = null): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.round(Ui.CARD, dp(20), Ui.STROKE)
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        if (title != null) c.addView(label(title, 15f, Ui.TEXT, true))
        root.addView(c, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })
        return c
    }

    private fun btnLp() = LinearLayout.LayoutParams(MATCH, dp(48)).apply { topMargin = dp(12) }

    private fun button(t: String, filled: Boolean, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        stateListAnimator = null
        setTextColor(if (filled) Color.WHITE else Ui.ACCENT)
        background = Ui.round(if (filled) Ui.ACCENT else Ui.CARD2, dp(14))
        setOnClickListener { onClick() }
    }

    private fun iconBtn(t: String, enabled: Boolean, color: Int, onClick: () -> Unit) = TextView(this).apply {
        text = t
        textSize = 16f
        gravity = Gravity.CENTER
        setTextColor(color)
        alpha = if (enabled) 1f else 0.25f
        isEnabled = enabled
        layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
        background = Ui.pressable(dp(22))
        setOnClickListener { onClick() }
    }

    /** Pilihan segmen (pengganti radio button) dengan tampilan lebih rapi. */
    private fun segmented(
        parent: LinearLayout, options: List<String>, selected: Int, onSelect: (Int) -> Unit
    ): LinearLayout {
        val row = LinearLayout(this).apply {
            background = Ui.round(Ui.CARD2, dp(13))
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        val cells = options.map { o ->
            TextView(this).apply {
                text = o
                textSize = 13f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
            }
        }
        fun paint(sel: Int) {
            cells.forEachIndexed { i, t ->
                t.background = if (i == sel) Ui.round(Ui.ACCENT, dp(10)) else null
                t.setTextColor(if (i == sel) Color.WHITE else Ui.SUB)
            }
        }
        cells.forEachIndexed { i, t ->
            t.setOnClickListener { paint(i); onSelect(i) }
            row.addView(t, LinearLayout.LayoutParams(0, dp(38), 1f))
        }
        paint(selected.coerceIn(0, options.lastIndex))
        parent.addView(row, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
        return row
    }

    private fun slider(
        parent: LinearLayout, name: String, min: Int, max: Int, value: Int, unit: String, onChange: (Int) -> Unit
    ) {
        val lbl = label("$name  $value$unit", 13f, Ui.TEXT).apply { setPadding(0, dp(14), 0, 0) }
        val sb = SeekBar(this).apply {
            this.max = max - min
            progress = (value - min).coerceIn(0, max - min)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    val v = p + min
                    lbl.text = "$name  $v$unit"
                    if (fromUser) onChange(v)
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        parent.addView(lbl)
        parent.addView(sb)
    }
}
