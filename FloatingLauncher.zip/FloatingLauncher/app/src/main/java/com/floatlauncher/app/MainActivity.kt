package com.floatlauncher.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import kotlin.math.roundToInt

/** Layar pengaturan (dibangun lewat kode: tanpa XML layout & tanpa library UI tambahan). */
class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var root: LinearLayout
    private lateinit var permText: TextView
    private lateinit var permBtn: Button
    private lateinit var svcBtn: Button
    private lateinit var appsList: LinearLayout
    private lateinit var durationGroup: RadioGroup
    private val handler = Handler(Looper.getMainLooper())
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        AppRepo.seedDefaults(this, prefs)
        setContentView(buildUi())
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        renderApps()
    }

    // ───────────────────────── UI ─────────────────────────

    private fun buildUi(): View {
        val scroll = ScrollView(this).apply { setBackgroundColor(Ui.BG); isVerticalScrollBarEnabled = false }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(32))
        }
        scroll.addView(root)

        root.addView(label("Floating Launcher", 26f, Ui.TEXT, true))
        root.addView(
            label("Tombol melayang untuk membuka aplikasi dari atas aplikasi apa pun.", 13f, Ui.SUB)
                .apply { setPadding(0, dp(4), 0, dp(4)) }
        )

        // Status & kontrol layanan
        val status = card("Status")
        permText = label("", 13f, Ui.TEXT).apply { setPadding(0, dp(8), 0, 0) }
        status.addView(permText)
        permBtn = button("Berikan izin \"Tampil di atas aplikasi lain\"", false) { openOverlaySettings() }
        status.addView(permBtn, btnLp())
        svcBtn = button("Mulai Overlay", true) { toggleService() }
        status.addView(svcBtn, btnLp())

        // Mode tombol
        val mode = card("Mode Tombol", "Atur kapan tombol tampil dan bersembunyi")
        choices(
            mode,
            listOf(
                "Always Visible — selalu tampil",
                "Auto Hide — sembunyi otomatis, muncul lagi saat layar diketuk",
                "Manual Hide — tekan lama tombol untuk menyembunyikan"
            ),
            prefs.mode, true
        ) { prefs.mode = it; updateDurationEnabled() }

        mode.addView(
            Switch(this).apply {
                text = "Mode Invisible"
                textSize = 14f
                setTextColor(Ui.TEXT)
                isChecked = prefs.invisible
                setOnCheckedChangeListener { _, c -> prefs.invisible = c; updateDurationEnabled() }
            },
            LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) }
        )
        mode.addView(
            label(
                "Tombol disembunyikan sepenuhnya. Munculkan sementara lewat tombol di notifikasi atau tile Quick Settings.",
                12f, Ui.SUB
            ).apply { setPadding(0, dp(2), 0, 0) }
        )

        mode.addView(label("Durasi Auto Hide", 13f, Ui.TEXT).apply { setPadding(0, dp(16), 0, 0) })
        durationGroup = choices(
            mode, Prefs.AUTO_OPTIONS.map { "$it dtk" },
            Prefs.AUTO_OPTIONS.indexOf(prefs.autoSec).coerceAtLeast(0), false
        ) { prefs.autoSec = Prefs.AUTO_OPTIONS[it] }
        updateDurationEnabled()

        // Tampilan & posisi
        val look = card("Tampilan & Posisi")
        slider(look, "Ukuran", 36, 80, prefs.sizeDp, " dp") { prefs.sizeDp = it }
        slider(look, "Transparansi (opasitas)", 20, 100, prefs.alphaPct, "%") { prefs.alphaPct = it }
        slider(look, "Posisi vertikal", 0, 100, (prefs.yFrac * 100).roundToInt(), "%") { prefs.yFrac = it / 100f }
        look.addView(label("Sisi layar", 13f, Ui.TEXT).apply { setPadding(0, dp(14), 0, 0) })
        choices(look, listOf("Kiri", "Kanan"), prefs.side, false) { prefs.side = it }

        // Aplikasi
        val apps = card("Aplikasi di Floating Menu", "Urutkan dengan ▲ ▼, hapus dengan ✕")
        appsList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        apps.addView(appsList)
        apps.addView(
            button("+ Tambah Aplikasi", true) { startActivity(Intent(this, AppPickerActivity::class.java)) },
            btnLp()
        )

        // Tips
        val tips = card("Cara pakai")
        tips.addView(
            label(
                "• Ketuk tombol: buka/tutup menu aplikasi\n" +
                    "• Seret tombol: pindahkan (otomatis menempel ke tepi)\n" +
                    "• Tekan lama: sembunyikan (mode Auto/Manual)\n" +
                    "• Munculkan lagi: ketuk layar (Auto Hide), tombol notifikasi, atau tile Quick Settings",
                12f, Ui.SUB
            ).apply { setPadding(0, dp(8), 0, 0); setLineSpacing(dp(3).toFloat(), 1f) }
        )
        return scroll
    }

    private fun updateDurationEnabled() {
        val on = prefs.mode == Prefs.MODE_AUTO || prefs.invisible
        for (i in 0 until durationGroup.childCount) durationGroup.getChildAt(i).isEnabled = on
        durationGroup.alpha = if (on) 1f else 0.4f
    }

    private fun refreshStatus() {
        val granted = Settings.canDrawOverlays(this)
        permText.text = if (granted) "Izin overlay: aktif ✓" else "Izin overlay: belum diberikan"
        permText.setTextColor(if (granted) Ui.GOOD else Ui.BAD)
        permBtn.visibility = if (granted) View.GONE else View.VISIBLE
        val running = OverlayService.running
        svcBtn.text = if (running) "Hentikan Overlay" else "Mulai Overlay"
        svcBtn.setTextColor(if (running) Ui.BAD else Color.WHITE)
        svcBtn.background = Ui.round(if (running) 0xFF3A2226.toInt() else Ui.ACCENT, dp(14))
    }

    private fun toggleService() {
        if (!Settings.canDrawOverlays(this)) {
            openOverlaySettings()
            return
        }
        val i = Intent(this, OverlayService::class.java)
        if (OverlayService.running) stopService(i) else startForegroundService(i)
        handler.postDelayed({ refreshStatus() }, 400)
    }

    private fun openOverlaySettings() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun renderApps() {
        appsList.removeAllViews()
        val list = prefs.apps
        if (list.isEmpty()) {
            appsList.addView(
                label("Belum ada aplikasi. Tekan \"Tambah Aplikasi\".", 13f, Ui.SUB)
                    .apply { setPadding(0, dp(10), 0, dp(4)) }
            )
            return
        }
        list.forEachIndexed { i, pkg ->
            val info = AppRepo.resolve(this, pkg)
            val row = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(6), 0, dp(6))
            }
            row.addView(
                ImageView(this).apply { if (info != null) setImageDrawable(info.icon) },
                LinearLayout.LayoutParams(dp(36), dp(36))
            )
            row.addView(
                label(info?.label ?: "$pkg (tidak terpasang)", 14f, if (info != null) Ui.TEXT else Ui.SUB).apply {
                    setPadding(dp(12), 0, dp(8), 0)
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                },
                LinearLayout.LayoutParams(0, WRAP, 1f)
            )
            row.addView(iconBtn("▲", i > 0, Ui.SUB) { move(i, i - 1) })
            row.addView(iconBtn("▼", i < list.lastIndex, Ui.SUB) { move(i, i + 1) })
            row.addView(iconBtn("✕", true, Ui.BAD) {
                prefs.apps = list.toMutableList().also { it.removeAt(i) }
                renderApps()
            })
            appsList.addView(row)
        }
    }

    private fun move(from: Int, to: Int) {
        val l = prefs.apps.toMutableList()
        if (to !in l.indices) return
        val item = l.removeAt(from)
        l.add(to, item)
        prefs.apps = l
        renderApps()
    }

    // ───────────────────────── helpers ─────────────────────────

    private fun label(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun card(title: String, sub: String? = null): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.round(Ui.CARD, dp(18), Ui.STROKE)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        c.addView(label(title, 16f, Ui.TEXT, true))
        if (sub != null) c.addView(label(sub, 12f, Ui.SUB).apply { setPadding(0, dp(2), 0, 0) })
        root.addView(c, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })
        return c
    }

    private fun btnLp() = LinearLayout.LayoutParams(MATCH, dp(46)).apply { topMargin = dp(10) }

    private fun button(t: String, filled: Boolean, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        textSize = 14f
        stateListAnimator = null
        setTextColor(if (filled) Color.WHITE else Ui.ACCENT)
        background = Ui.round(if (filled) Ui.ACCENT else Ui.CARD2, dp(14))
        setOnClickListener { onClick() }
    }

    private fun iconBtn(t: String, enabled: Boolean, color: Int, onClick: () -> Unit) = TextView(this).apply {
        text = t
        textSize = 16f
        gravity = Gravity.CENTER
        setTextColor(color)
        alpha = if (enabled) 1f else 0.25f
        isEnabled = enabled
        layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
        background = Ui.pressable(dp(22))
        setOnClickListener { onClick() }
    }

    private fun choices(
        parent: LinearLayout, options: List<String>, selected: Int, vertical: Boolean, onSelect: (Int) -> Unit
    ): RadioGroup {
        val g = RadioGroup(this).apply {
            orientation = if (vertical) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
        }
        val ids = options.map { View.generateViewId() }
        options.forEachIndexed { i, o ->
            g.addView(RadioButton(this).apply {
                id = ids[i]
                text = o
                textSize = 13f
                setTextColor(Ui.TEXT)
            })
        }
        g.check(ids[selected.coerceIn(0, options.lastIndex)])
        g.setOnCheckedChangeListener { _, id -> onSelect(ids.indexOf(id)) }
        parent.addView(g, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        return g
    }

    private fun slider(
        parent: LinearLayout, name: String, min: Int, max: Int, value: Int, unit: String, onChange: (Int) -> Unit
    ) {
        val lbl = label("$name: $value$unit", 13f, Ui.TEXT).apply { setPadding(0, dp(14), 0, 0) }
        val sb = SeekBar(this).apply {
            this.max = max - min
            progress = (value - min).coerceIn(0, max - min)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    val v = p + min
                    lbl.text = "$name: $v$unit"
                    if (fromUser) onChange(v)
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        parent.addView(lbl)
        parent.addView(sb)
    }
}
