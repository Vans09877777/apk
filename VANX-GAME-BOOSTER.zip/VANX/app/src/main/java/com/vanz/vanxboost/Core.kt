package com.vanz.vanxboost

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.Process
import android.os.StatFs
import android.os.SystemClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject

/** Semua nilai berasal dari API Android resmi. Tidak ada angka simulasi. */
data class Snap(
    val ramTotalMb: Long, val ramAvailMb: Long, val lowMem: Boolean,
    val batPct: Int, val charging: Boolean, val batTempC: Float,
    val thermal: Int, val headroom: Float,
    val storUsedGb: Float, val storTotalGb: Float, val net: String
) { val ramUsedMb get() = ramTotalMb - ramAvailMb }

object Sys {
    fun snap(c: Context): Snap {
        val mi = ActivityManager.MemoryInfo()
        c.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        val b = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val st = b?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val temp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val pm = c.getSystemService(PowerManager::class.java)
        val head = if (Build.VERSION.SDK_INT >= 30) pm.getThermalHeadroom(10) else Float.NaN
        val sf = StatFs(Environment.getDataDirectory().path)
        val cm = c.getSystemService(ConnectivityManager::class.java)
        val caps = cm.activeNetwork?.let { cm.getNetworkCapabilities(it) }
        val net = when {
            caps == null -> "Tidak terhubung"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Seluler"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Terhubung"
        }
        val gb = 1024f * 1024f * 1024f
        return Snap(
            mi.totalMem / 1048576, mi.availMem / 1048576, mi.lowMemory,
            if (lvl < 0) 0 else lvl * 100 / scale,
            st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL,
            temp, pm.currentThermalStatus, head,
            (sf.totalBytes - sf.availableBytes) / gb, sf.totalBytes / gb, net
        )
    }

    fun thermalLabel(s: Int): String =
        listOf("Normal", "Ringan", "Sedang", "Berat", "Kritis", "Darurat", "Shutdown").getOrElse(s) { "?" }
}

/** Pemakaian CPU proses aplikasi ini saja (CPU sistem/game lain tidak bisa dibaca sejak Android 8). */
class CpuMeter {
    private var lastCpu = Process.getElapsedCpuTime()
    private var lastReal = SystemClock.elapsedRealtime()
    fun pct(): Float {
        val cpu = Process.getElapsedCpuTime(); val real = SystemClock.elapsedRealtime()
        val v = (cpu - lastCpu) * 100f / (real - lastReal).coerceAtLeast(1)
        lastCpu = cpu; lastReal = real
        return v.coerceAtLeast(0f)
    }
}

data class AppItem(val pkg: String, val label: String, val isGame: Boolean)

val KNOWN_GAMES = setOf(
    "com.dts.freefireth", "com.dts.freefiremax", "com.mobile.legends", "com.tencent.ig",
    "com.pubg.imobile", "com.activision.callofduty.shooter", "com.mojang.minecraftpe"
)

fun scanApps(c: Context): List<AppItem> {
    val pm = c.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .map { it.activityInfo.applicationInfo }
        .distinctBy { it.packageName }
        .filter { it.packageName != c.packageName }
        .map {
            AppItem(
                it.packageName, pm.getApplicationLabel(it).toString(),
                it.category == ApplicationInfo.CATEGORY_GAME || it.packageName in KNOWN_GAMES
            )
        }
        .sortedBy { it.label.lowercase() }
}

data class Profile(
    val mode: String = "BALANCED", val dnd: Boolean = false,
    val clean: Boolean = false, val overlay: Boolean = false, val warnC: Int = 42
)

fun pollMs(mode: String): Long = when (mode) { "PERFORMANCE" -> 5000L; "BATTERY" -> 10000L; else -> 2000L }

class Store(c: Context) {
    private val sp = c.getSharedPreferences("vanx", Context.MODE_PRIVATE)
    fun library(): Set<String> = sp.getStringSet("lib", emptySet())?.toSet() ?: emptySet()
    fun setLibrary(s: Set<String>) { sp.edit().putStringSet("lib", s).apply() }
    fun profile(key: String): Profile {
        val j = sp.getString("p_$key", null)
            ?: return if (key in KNOWN_GAMES) Profile("PERFORMANCE", dnd = true) else Profile()
        return runCatching {
            JSONObject(j).let {
                Profile(it.getString("mode"), it.getBoolean("dnd"), it.getBoolean("clean"), it.getBoolean("overlay"), it.getInt("warnC"))
            }
        }.getOrDefault(Profile())
    }
    fun saveProfile(key: String, p: Profile) {
        val j = JSONObject().put("mode", p.mode).put("dnd", p.dnd).put("clean", p.clean)
            .put("overlay", p.overlay).put("warnC", p.warnC)
        sp.edit().putString("p_$key", j.toString()).apply()
    }
    var minAnim: Boolean
        get() = sp.getBoolean("minAnim", false)
        set(v) { sp.edit().putBoolean("minAnim", v).apply() }
    var prevFilter: Int
        get() = sp.getInt("prevFilter", -1)
        set(v) { sp.edit().putInt("prevFilter", v).apply() }
}

data class BoostResult(val lines: List<String>, val freedMb: Long?)

/** BOOST nyata: analisis kondisi perangkat + tindakan yang diizinkan Android. */
suspend fun runBoost(c: Context, p: Profile, keepPkg: String?, store: Store): BoostResult =
    withContext(Dispatchers.IO) {
        val b = Sys.snap(c)
        val out = mutableListOf<String>()
        out += "RAM bebas ${b.ramAvailMb} dari ${b.ramTotalMb} MB" + if (b.lowMem) " (RENDAH)" else ""
        out += "Baterai ${b.batPct}%" + (if (b.charging) ", mengisi" else "") +
            if (!b.charging && b.batPct < 20) " (rendah, sebaiknya dicas)" else ""
        out += "Termal: ${Sys.thermalLabel(b.thermal)}, suhu baterai ${"%.1f".format(b.batTempC)}°C" +
            if (b.thermal >= 2 || b.batTempC >= p.warnC) " (panas, istirahatkan perangkat)" else ""
        out += "Jaringan: ${b.net}" + if (b.net == "Tidak terhubung") " (game online tidak akan jalan)" else ""
        out += "Mode ${p.mode}: monitor booster berjalan tiap ${pollMs(p.mode) / 1000} detik"
        if (p.mode == "PERFORMANCE") store.minAnim = true
        out += if (store.minAnim) "Mode minim animasi aktif" else "Animasi normal"
        out += if (p.dnd) "Jangan Ganggu akan aktif saat game berjalan (butuh izin)" else "Jangan Ganggu mati"
        var freed: Long? = null
        if (p.clean) {
            val am = c.getSystemService(ActivityManager::class.java)
            val pm = c.packageManager
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val targets = pm.queryIntentActivities(i, 0).map { it.activityInfo.applicationInfo }
                .filter { it.flags and ApplicationInfo.FLAG_SYSTEM == 0 && it.packageName != c.packageName && it.packageName != keepPkg }
                .map { it.packageName }.distinct()
            targets.forEach { am.killBackgroundProcesses(it) }
            delay(800)
            freed = Sys.snap(c).ramAvailMb - b.ramAvailMb
            out += "Proses latar dibersihkan (${targets.size} app dicoba). RAM bebas berubah ${if (freed >= 0) "+" else ""}$freed MB (terukur)"
        } else out += "Pembersihan proses latar: mati"
        BoostResult(out, freed)
    }
