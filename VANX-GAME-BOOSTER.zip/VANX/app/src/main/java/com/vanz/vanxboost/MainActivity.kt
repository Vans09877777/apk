package com.vanz.vanxboost

import android.Manifest
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

val Neon = Color(0xFF00D4FF)
val Purple = Color(0xFF8B5CF6)
val Bg = Color(0xFF000000)
val Dim = Color(0xFF9AA0B5)
private val VanxColors = darkColorScheme(
    primary = Neon, secondary = Purple, background = Bg, surface = Color(0xFF0B0B14),
    onBackground = Color.White, onSurface = Color.White, onPrimary = Color.Black
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent { MaterialTheme(colorScheme = VanxColors) { App() } }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    var tab by remember { mutableIntStateOf(0) }
    var launching by remember { mutableStateOf<AppItem?>(null) }
    val tabs = listOf(
        "Home" to Icons.Default.Home, "Games" to Icons.Default.PlayArrow, "Booster" to Icons.Default.Build,
        "Monitor" to Icons.Default.Info, "Settings" to Icons.Default.Settings
    )
    Box(Modifier.fillMaxSize().background(Bg)) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF07070D)) {
                    tabs.forEachIndexed { i, (n, ic) ->
                        NavigationBarItem(selected = tab == i, onClick = { tab = i },
                            icon = { Icon(ic, n) }, label = { Text(n, fontSize = 10.sp) })
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0 -> Home(store) { tab = 2 }
                    1 -> Games(store) { launching = it }
                    2 -> Booster(store)
                    3 -> Monitor(store)
                    else -> SettingsScreen()
                }
            }
        }
        launching?.let { LaunchScreen(it, store) { launching = null } }
    }
}

@Composable
fun Glass(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    var m = modifier.fillMaxWidth().clip(shape)
        .background(Brush.linearGradient(listOf(Color(0x22FFFFFF), Color(0x0AFFFFFF))))
        .border(1.dp, Brush.linearGradient(listOf(Neon.copy(alpha = .5f), Purple.copy(alpha = .5f))), shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(m.padding(14.dp), content = content)
}

@Composable
fun Stat(title: String, value: String, sub: String, m: Modifier = Modifier) = Glass(m) {
    Text(title, color = Dim, fontSize = 12.sp)
    Text(value, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    Text(sub, color = Neon, fontSize = 11.sp)
}

@Composable
fun rememberSnap(ms: Long): State<Snap?> {
    val c = LocalContext.current
    return produceState<Snap?>(null, ms) {
        while (true) { value = withContext(Dispatchers.IO) { Sys.snap(c) }; delay(ms) }
    }
}

@Composable
fun Home(store: Store, goBooster: () -> Unit) {
    val c = LocalContext.current
    val s by rememberSnap(pollMs(store.profile("_global").mode))
    val sess by GameSessionService.state.collectAsState()
    val elapsed by produceState(0L) {
        while (true) { value = GameSessionService.state.value?.let { (SystemClock.elapsedRealtime() - it.startMs) / 1000 } ?: 0L; delay(1000) }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("VANX GAME BOOSTER", color = Neon, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        sess?.let { x ->
            Glass {
                Text("Sesi aktif: ${x.label}", color = Color.White, fontWeight = FontWeight.Bold)
                Text("%d:%02d:%02d".format(elapsed / 3600, elapsed % 3600 / 60, elapsed % 60), color = Neon, fontSize = 28.sp)
                OutlinedButton(onClick = { GameSessionService.stop(c) }) { Text("Hentikan sesi") }
            }
        }
        val x = s
        if (x == null) CircularProgressIndicator(color = Neon) else {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Stat("RAM bebas", "${x.ramAvailMb} MB", "dipakai ${x.ramUsedMb} / ${x.ramTotalMb} MB", Modifier.weight(1f))
                Stat("Baterai", "${x.batPct}%", if (x.charging) "Mengisi daya" else "Tidak mengisi", Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Stat("Suhu baterai", "%.1f°C".format(x.batTempC), "Termal: ${Sys.thermalLabel(x.thermal)}", Modifier.weight(1f))
                Stat("Penyimpanan", "%.1f GB".format(x.storUsedGb), "dari %.1f GB".format(x.storTotalGb), Modifier.weight(1f))
            }
            Stat("Jaringan", x.net, "")
        }
        Glass {
            Text("Perangkat", color = Dim, fontSize = 12.sp)
            Text("${Build.MANUFACTURER} ${Build.MODEL}", color = Color.White, fontWeight = FontWeight.Bold)
            Text("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) | ${Build.SUPPORTED_ABIS.firstOrNull() ?: "?"} | ${Runtime.getRuntime().availableProcessors()} core", color = Color.White, fontSize = 12.sp)
        }
        Button(onClick = goBooster, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Quick Boost", fontWeight = FontWeight.Bold) }
    }
}

@Composable
fun AppIcon(pkg: String, size: Dp = 44.dp) {
    val c = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, pkg) {
        value = withContext(Dispatchers.IO) {
            runCatching { c.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap() }.getOrNull()
        }
    }
    val b = bmp
    if (b != null) Image(b, null, Modifier.size(size).clip(RoundedCornerShape(10.dp)))
    else Box(Modifier.size(size).background(Color(0x22FFFFFF), RoundedCornerShape(10.dp)))
}

@Composable
fun SwitchRow(label: String, v: Boolean, on: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), color = Color.White, fontSize = 13.sp)
        Switch(v, on)
    }
}

@Composable
fun ProfileForm(p: Profile, onChange: (Profile) -> Unit) {
    Column {
        Text("Mode performa", color = Neon, fontWeight = FontWeight.Bold)
        listOf(
            "BALANCED" to "Balanced: monitor tiap 2 dtk, seimbang",
            "PERFORMANCE" to "Performance: monitor tiap 5 dtk, animasi minim",
            "BATTERY" to "Battery Saver: monitor tiap 10 dtk, paling hemat"
        ).forEach { (k, l) ->
            Row(Modifier.fillMaxWidth().clickable { onChange(p.copy(mode = k)) }, verticalAlignment = Alignment.CenterVertically) {
                RadioButton(p.mode == k, { onChange(p.copy(mode = k)) })
                Text(l, fontSize = 12.sp, color = Color.White)
            }
        }
        SwitchRow("Jangan Ganggu saat bermain", p.dnd) { onChange(p.copy(dnd = it)) }
        SwitchRow("Bersihkan proses latar (efek terbatas)", p.clean) { onChange(p.copy(clean = it)) }
        SwitchRow("Floating monitor", p.overlay) { onChange(p.copy(overlay = it)) }
        Text("Peringatan panas di ${p.warnC}°C", color = Color.White, fontSize = 13.sp)
        Slider(p.warnC.toFloat(), { onChange(p.copy(warnC = it.toInt())) }, valueRange = 36f..50f)
    }
}

@Composable
fun ProfileDialog(title: String, init: Profile, onSave: (Profile) -> Unit, onDismiss: () -> Unit) {
    var p by remember { mutableStateOf(init) }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = Color(0xFF10101C),
        title = { Text("Profil: $title") },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) { ProfileForm(p) { p = it } } },
        confirmButton = { TextButton({ onSave(p) }) { Text("Simpan") } },
        dismissButton = { TextButton(onDismiss) { Text("Batal") } }
    )
}

@Composable
fun AppRow(a: AppItem, inLib: Boolean, onOpen: () -> Unit, onProfile: () -> Unit, onToggle: () -> Unit) {
    Glass(Modifier.padding(vertical = 4.dp), onClick = onOpen) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AppIcon(a.pkg)
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text(a.label, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(a.pkg, color = Dim, fontSize = 10.sp, maxLines = 1)
            }
            if (inLib) {
                IconButton(onProfile) { Icon(Icons.Default.Settings, "Profil", tint = Neon) }
                IconButton(onToggle) { Icon(Icons.Default.Delete, "Hapus", tint = Purple) }
            } else IconButton(onToggle) { Icon(Icons.Default.Add, "Tambah", tint = Neon) }
        }
    }
}

@Composable
fun Header(t: String) = Text(t, color = Neon, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp, bottom = 4.dp))

@Composable
fun Games(store: Store, onLaunch: (AppItem) -> Unit) {
    val c = LocalContext.current
    var apps by remember { mutableStateOf<List<AppItem>?>(null) }
    var lib by remember { mutableStateOf(store.library()) }
    var q by remember { mutableStateOf("") }
    var tab by remember { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<AppItem?>(null) }
    LaunchedEffect(Unit) { apps = withContext(Dispatchers.IO) { scanApps(c) } }
    fun toggle(pkg: String) { lib = if (pkg in lib) lib - pkg else lib + pkg; store.setLibrary(lib) }
    val f = (apps ?: emptyList()).filter { it.label.contains(q, true) || it.pkg.contains(q, true) }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(top = 12.dp), label = { Text("Cari aplikasi") }, singleLine = true)
        TabRow(tab, containerColor = Color.Transparent, contentColor = Neon) {
            Tab(tab == 0, { tab = 0 }, text = { Text("Games") })
            Tab(tab == 1, { tab = 1 }, text = { Text("Apps") })
        }
        if (apps == null) Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = Neon) }
        else LazyColumn(Modifier.fillMaxSize()) {
            if (tab == 0) {
                val mine = f.filter { it.pkg in lib }
                val det = f.filter { it.isGame && it.pkg !in lib }
                item(key = "h1") { Header("Game Library (${mine.size})") }
                if (mine.isEmpty()) item(key = "e1") { Text("Kosong. Tambahkan dari daftar terdeteksi atau tab Apps.", color = Dim, fontSize = 12.sp) }
                items(mine, key = { "m_" + it.pkg }) { a -> AppRow(a, true, { onLaunch(a) }, { editing = a }, { toggle(a.pkg) }) }
                item(key = "h2") { Header("Game terdeteksi") }
                items(det, key = { "d_" + it.pkg }) { a -> AppRow(a, false, { onLaunch(a) }, {}, { toggle(a.pkg) }) }
            } else {
                items(f.filter { it.pkg !in lib }, key = { "a_" + it.pkg }) { a -> AppRow(a, false, { onLaunch(a) }, {}, { toggle(a.pkg) }) }
            }
        }
    }
    editing?.let { a ->
        ProfileDialog(a.label, store.profile(a.pkg), { store.saveProfile(a.pkg, it); editing = null }, { editing = null })
    }
}

@Composable
fun Booster(store: Store) {
    val c = LocalContext.current
    val scope = rememberCoroutineScope()
    var p by remember { mutableStateOf(store.profile("_global")) }
    var res by remember { mutableStateOf<BoostResult?>(null) }
    var busy by remember { mutableStateOf(false) }
    var minAnim by remember { mutableStateOf(store.minAnim) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Smart Booster", color = Neon, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Button(
            onClick = { busy = true; scope.launch { res = runBoost(c, p, null, store); minAnim = store.minAnim; busy = false } },
            enabled = !busy, modifier = Modifier.fillMaxWidth().height(64.dp)
        ) { Text(if (busy) "Menganalisis..." else "BOOST", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
        res?.let { r -> Glass { r.lines.forEach { Text("• $it", color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(vertical = 2.dp)) } } }
        Glass {
            ProfileForm(p) { p = it; store.saveProfile("_global", it) }
            SwitchRow("Mode minim animasi", minAnim) { minAnim = it; store.minAnim = it }
        }
        Glass {
            Text("Jujur soal batasan", color = Neon, fontWeight = FontWeight.Bold)
            Text("Android tidak mengizinkan aplikasi biasa mengubah CPU/GPU, overclock, atau mematikan semua proses lain. BOOST hanya menganalisis kondisi, meringankan kerja booster ini, membersihkan proses latar non-sistem lewat API resmi (hasil RAM diukur, bisa nol), dan menyiapkan sesi gaming. Tidak ada klaim kenaikan FPS.", color = Dim, fontSize = 12.sp)
        }
    }
}

@Composable
fun rememberOwnFps(): State<Int> {
    val fps = remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        var frames = 0; var t0 = 0L
        while (true) {
            val t = withFrameNanosCompat()
            if (t0 == 0L) t0 = t
            frames++
            if (t - t0 >= 1_000_000_000L) { fps.intValue = frames; frames = 0; t0 = t }
        }
    }
    return fps
}

private suspend fun withFrameNanosCompat(): Long = androidx.compose.runtime.withFrameNanos { it }

@Composable
fun Monitor(store: Store) {
    val s by rememberSnap(1000L)
    val fps by rememberOwnFps()
    val meter = remember { CpuMeter() }
    val cpu by produceState(0f) { while (true) { delay(1000); value = meter.pct() } }
    val warnC = store.profile("_global").warnC
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Monitor", color = Neon, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        val x = s
        if (x == null) { CircularProgressIndicator(color = Neon); return@Column }
        if (x.batTempC >= warnC || x.thermal >= 3) Glass {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Warning, null, tint = Color(0xFFFF5252))
                Text("  Perangkat panas. Turunkan grafik atau istirahat.", color = Color(0xFFFF5252), fontWeight = FontWeight.Bold)
            }
        }
        Glass {
            Text("RAM", color = Dim, fontSize = 12.sp)
            Text("${x.ramUsedMb} / ${x.ramTotalMb} MB dipakai", color = Color.White, fontWeight = FontWeight.Bold)
            LinearProgressIndicator({ x.ramUsedMb.toFloat() / x.ramTotalMb.coerceAtLeast(1) }, Modifier.fillMaxWidth().padding(top = 6.dp), color = Neon)
            if (x.lowMem) Text("Sistem melaporkan memori rendah", color = Color(0xFFFF5252), fontSize = 12.sp)
        }
        Glass {
            Text("Suhu", color = Dim, fontSize = 12.sp)
            Text("Baterai: %.1f°C".format(x.batTempC), color = Color.White, fontWeight = FontWeight.Bold)
            Text("Status termal sistem: ${Sys.thermalLabel(x.thermal)}", color = Color.White, fontSize = 13.sp)
            Text(
                if (x.headroom.isNaN()) "Thermal headroom: tidak didukung perangkat ini"
                else "Thermal headroom (10 dtk ke depan): %.2f (1.0 = batas throttling)".format(x.headroom),
                color = Color.White, fontSize = 13.sp
            )
            Text("Suhu CPU: tidak tersedia. Android tidak mengizinkan aplikasi biasa membaca sensor CPU; ini bukan suhu baterai.", color = Dim, fontSize = 11.sp)
        }
        Glass {
            Text("CPU", color = Dim, fontSize = 12.sp)
            Text("Proses aplikasi ini: %.1f%%".format(cpu), color = Color.White, fontWeight = FontWeight.Bold)
            Text("CPU sistem dan game lain tidak bisa dibaca aplikasi biasa sejak Android 8.", color = Dim, fontSize = 11.sp)
        }
        Glass {
            Text("FPS", color = Dim, fontSize = 12.sp)
            Text("$fps FPS (layar aplikasi ini)", color = Color.White, fontWeight = FontWeight.Bold)
            Text("FPS game lain tidak bisa dibaca lewat API publik, jadi tidak ditampilkan angka palsu.", color = Dim, fontSize = 11.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Stat("Baterai", "${x.batPct}%", if (x.charging) "Mengisi" else "Tidak mengisi", Modifier.weight(1f))
            Stat("Jaringan", x.net, "", Modifier.weight(1f))
        }
    }
}

@Composable
fun SettingsScreen() {
    val c = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(o)
        onDispose { owner.lifecycle.removeObserver(o) }
    }
    val overlayOk = remember(tick) { Settings.canDrawOverlays(c) }
    val dndOk = remember(tick) { c.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", color = Neon, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Glass {
            Text("Izin (diberikan manual oleh pengguna)", color = Neon, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Floating overlay: ${if (overlayOk) "aktif" else "belum"}", Modifier.weight(1f), color = Color.White)
                Button({ c.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${c.packageName}"))) }) { Text("Atur") }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Jangan Ganggu: ${if (dndOk) "aktif" else "belum"}", Modifier.weight(1f), color = Color.White)
                Button({ c.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }) { Text("Atur") }
            }
        }
        Glass {
            Text("Tentang", color = Neon, fontWeight = FontWeight.Bold)
            Text("VANX GAME BOOSTER v1.0.0\nDeveloper: VANZ", color = Color.White)
            Text("Tanpa root, tanpa exploit. Semua data dari API Android resmi.", color = Dim, fontSize = 12.sp)
        }
    }
}

@Composable
fun LaunchScreen(a: AppItem, store: Store, onClose: () -> Unit) {
    val c = LocalContext.current
    val p = remember { store.profile(a.pkg) }
    var lines by remember { mutableStateOf(listOf<String>()) }
    var err by remember { mutableStateOf<String?>(null) }
    var target by remember { mutableFloatStateOf(0.1f) }
    val prog by animateFloatAsState(target, if (store.minAnim) snap() else tween(700), label = "p")
    BackHandler(onBack = onClose)
    LaunchedEffect(a.pkg) {
        val r = runBoost(c, p, a.pkg, store)
        lines = r.lines; target = 0.7f
        delay(if (store.minAnim) 300 else 1200)
        val intent = c.packageManager.getLaunchIntentForPackage(a.pkg)
        if (intent == null) { err = "Game tidak bisa dibuka: tidak ada activity peluncur."; return@LaunchedEffect }
        try {
            GameSessionService.start(c, a.pkg, a.label)
            c.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            target = 1f; onClose()
        } catch (e: Exception) {
            GameSessionService.stop(c); err = "Gagal membuka game: ${e.message}"
        }
    }
    Column(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Bg, Color(0xFF14082B)))).pointerInput(Unit) {}
            .verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Spacer(Modifier.height(48.dp))
        AppIcon(a.pkg, 96.dp)
        Text(a.label, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 12.dp))
        Text("Menyiapkan sesi gaming • profil ${p.mode}", color = Neon, fontSize = 12.sp)
        LinearProgressIndicator({ prog }, Modifier.fillMaxWidth().padding(vertical = 16.dp), color = Neon)
        lines.forEach { Text("• $it", color = Color.White, fontSize = 12.sp, modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) }
        err?.let {
            Text(it, color = Color(0xFFFF5252), modifier = Modifier.padding(top = 12.dp))
            Button(onClose, Modifier.padding(top = 8.dp)) { Text("Kembali") }
        }
    }
}
